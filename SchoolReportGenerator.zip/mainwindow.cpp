
#include "mainwindow.h"
#include <QVBoxLayout>
#include <QInputDialog>
#include <QFileDialog>
#include <QTextDocument>
#include <QPrinter>
#include <QPrintDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent) {
    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    table = new QTableWidget(0, 4, this);
    table->setHorizontalHeaderLabels({"Name", "Math", "Science", "English"});

    addButton = new QPushButton("Add Student", this);
    exportButton = new QPushButton("Export to PDF", this);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(table);
    layout->addWidget(addButton);
    layout->addWidget(exportButton);
    central->setLayout(layout);

    connect(addButton, &QPushButton::clicked, this, &MainWindow::addStudent);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportToPDF);
}

MainWindow::~MainWindow() {}

void MainWindow::addStudent() {
    QString name = QInputDialog::getText(this, "Student Name", "Enter name:");
    if (name.isEmpty()) return;

    int row = table->rowCount();
    table->insertRow(row);
    table->setItem(row, 0, new QTableWidgetItem(name));
    for (int i = 1; i < 4; ++i)
        table->setItem(row, i, new QTableWidgetItem("0"));
}

void MainWindow::exportToPDF() {
    QString filePath = QFileDialog::getSaveFileName(this, "Save PDF", "", "PDF Files (*.pdf)");
    if (filePath.isEmpty()) return;

    QTextDocument doc;
    QString html = "<h1>Student Report</h1><table border='1' cellspacing='0' cellpadding='2'>";
    html += "<tr><th>Name</th><th>Math</th><th>Science</th><th>English</th></tr>";

    for (int row = 0; row < table->rowCount(); ++row) {
        html += "<tr>";
        for (int col = 0; col < table->columnCount(); ++col) {
            QTableWidgetItem *item = table->item(row, col);
            html += "<td>" + (item ? item->text() : "") + "</td>";
        }
        html += "</tr>";
    }

    html += "</table>";
    doc.setHtml(html);

    QPrinter printer(QPrinter::PrinterResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName(filePath);
    doc.print(&printer);
}
