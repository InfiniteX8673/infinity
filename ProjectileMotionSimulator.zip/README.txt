Projectile Motion Simulator
===========================

This Qt C++ project allows you to:
- Simulate real-time projectile motion
- Save the motion graph as an image
- Export projectile stats like max height, range, and total time to a .txt file

INSTRUCTIONS:
1. Open the project in Qt Creator
2. Run the project
3. Input velocity, angle, and height, then click "Simulate"
4. Use "Save Graph" to save the trajectory
5. Use "Export Stats" to save physics data

Enjoy!