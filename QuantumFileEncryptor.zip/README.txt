
Quantum File Encryptor (Qt C++)

This application lets you encrypt and decrypt files using a simple reversible method (base64 + reverse).

To install:
1. Ensure Qt and Qt Creator are installed.
2. Open the .pro file or the project folder in Qt Creator.
3. Build and run the project.

All encryption and decryption is done locally and securely.
