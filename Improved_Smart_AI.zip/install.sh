#!/bin/bash
echo "Updating system and installing dependencies..."
sudo apt update
sudo apt install -y python3-pip python3-tk espeak ffmpeg libespeak1

echo "Installing Python packages..."
pip3 install --upgrade pip
pip3 install -r requirements.txt

echo "Setup complete. You can now run the AI using: python3 main.py"