import tkinter as tk
from tkinter import simpledialog
from PIL import Image, ImageTk
import threading
import cv2

from ai_core import SmartAI
from vision import ObjectDetector

class AIGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart AI Assistant")
        self.root.tk.call("source", "resources/dark_theme.tcl")
        self.root.tk.call("set_theme", "dark")

        self.ai = SmartAI()
        self.detector = ObjectDetector()
        self.cap = None
        self.running = False

        # Chat window
        self.chat_log = tk.Text(root, state='disabled', width=60, height=20)
        self.chat_log.pack(pady=5)

        # Entry and buttons
        self.entry = tk.Entry(root, width=50)
        self.entry.pack(side=tk.LEFT, padx=5)
        self.entry.bind("<Return>", self.respond)

        tk.Button(root, text="Send", command=self.respond).pack(side=tk.LEFT)
        tk.Button(root, text="Camera", command=self.toggle_camera).pack(side=tk.LEFT)

        self.video_label = tk.Label(root)
        self.video_label.pack()

    def update_chat(self, sender, text):
        self.chat_log.config(state='normal')
        self.chat_log.insert(tk.END, f"{sender}: {text}\n")
        self.chat_log.config(state='disabled')
        self.chat_log.see(tk.END)

    def respond(self, event=None):
        user_input = self.entry.get()
        self.entry.delete(0, tk.END)

        self.update_chat("You", user_input)
        response = self.ai.respond(user_input)

        self.update_chat("AI", response)

    def toggle_camera(self):
        if not self.running:
            self.running = True
            self.cap = cv2.VideoCapture(0)
            threading.Thread(target=self.camera_loop).start()
        else:
            self.running = False
            if self.cap:
                self.cap.release()
                self.video_label.config(image='')

    def camera_loop(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                break

            # Run object detection
            detected, names = self.detector.detect(frame)
            if names:
                self.update_chat("Camera", f"I see: {', '.join(names)}")

            # Show video
            img_rgb = cv2.cvtColor(detected, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(img_pil)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)

        if self.cap:
            self.cap.release()

if __name__ == "__main__":
    root = tk.Tk()
    app = AIGUI(root)
    root.mainloop()

