
School Report Generator - Qt C++ Project
---------------------------------------

This application allows you to add students and generate simple report cards
with marks for Math, Science, and English. Reports can be exported as PDF.

Requirements:
- Qt 5 or 6 (Tested with Qt 6)
- C++17 or later

To Build:
1. Open SchoolReportGenerator.pro in Qt Creator
2. Build and run

To Install Qt on Ubuntu:
$ sudo apt update
$ sudo apt install qtbase5-dev qtchooser qt5-qmake qtbase5-dev-tools

To Run:
$ ./SchoolReportGenerator
