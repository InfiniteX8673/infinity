from ultralytics import YOLO
import cv2

class ObjectDetector:
    def __init__(self):
        self.model = YOLO("yolov8n.pt")  # You can switch to yolov8s.pt if you want better accuracy

    def detect(self, frame):
        results = self.model.predict(source=frame, show=False, conf=0.4, verbose=False)
        names = []
        try:
            boxes = results[0].boxes
            for box in boxes:
                cls = int(box.cls[0])
                name = self.model.names[cls]
                names.append(name)
        except Exception:
            pass
        return frame, names

