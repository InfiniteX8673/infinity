#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGraphicsEllipseItem>
#include <QFileDialog>
#include <QTextStream>
#include <QImage>
#include <QPainter>
#include <QtMath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), timer(new QTimer(this)), time(0) {
    ui->setupUi(this);
    scene = new QGraphicsScene(this);
    ui->graphicsView->setScene(scene);
    connect(ui->simulateButton, &QPushButton::clicked, this, &MainWindow::simulate);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateProjectile);
    connect(ui->saveButton, &QPushButton::clicked, this, &MainWindow::saveGraph);
    connect(ui->exportButton, &QPushButton::clicked, this, &MainWindow::exportStats);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::simulate() {
    scene->clear();
    trajectory.clear();
    time = 0;
    posX = 0;
    posY = height = ui->heightBox->value();
    velocity = ui->velocityBox->value();
    angle = qDegreesToRadians(ui->angleBox->value());
    timer->start(30);
}

void MainWindow::updateProjectile() {
    const double g = 9.8;
    double vx = velocity * qCos(angle);
    double vy = velocity * qSin(angle) - g * time;
    posX = vx * time;
    posY = height + (velocity * qSin(angle) * time) - (0.5 * g * time * time);

    if (posY < 0) {
        timer->stop();
        return;
    }

    QPointF point(posX * 5, -posY * 5); // scaled for view
    trajectory.append(point);
    scene->addEllipse(point.x(), point.y(), 3, 3, QPen(Qt::blue), QBrush(Qt::blue));
    time += 0.1;
}

void MainWindow::saveGraph() {
    QImage image(scene->sceneRect().size().toSize(), QImage::Format_ARGB32);
    image.fill(Qt::white);
    QPainter painter(&image);
    scene->render(&painter);
    QString fileName = QFileDialog::getSaveFileName(this, "Save Graph", "", "PNG Image (*.png)");
    if (!fileName.isEmpty()) image.save(fileName);
}

void MainWindow::exportStats() {
    double maxHeight = height + (velocity * velocity * qSin(angle) * qSin(angle)) / (2 * 9.8);
    double range = (velocity * qCos(angle)) * ((velocity * qSin(angle)) + sqrt((velocity * qSin(angle)) * (velocity * qSin(angle)) + 2 * 9.8 * height)) / 9.8;
    double totalTime = ((velocity * qSin(angle)) + sqrt((velocity * qSin(angle)) * (velocity * qSin(angle)) + 2 * 9.8 * height)) / 9.8;

    QString fileName = QFileDialog::getSaveFileName(this, "Export Stats", "", "Text File (*.txt)");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << "Max Height: " << maxHeight << " m\n";
        out << "Range: " << range << " m\n";
        out << "Total Time: " << totalTime << " s\n";
    }
}