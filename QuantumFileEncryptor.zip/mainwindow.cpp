
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);
    connect(ui->encryptButton, &QPushButton::clicked, this, &MainWindow::encryptFile);
    connect(ui->decryptButton, &QPushButton::clicked, this, &MainWindow::decryptFile);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::encryptFile() {
    QString fileName = QFileDialog::getOpenFileName(this, "Select File to Encrypt");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly)) return;

    QByteArray data = file.readAll();
    file.close();

    QByteArray encrypted = quantumEncrypt(data);

    QString savePath = fileName + ".qenc";
    QFile outFile(savePath);
    if (outFile.open(QIODevice::WriteOnly)) {
        outFile.write(encrypted);
        outFile.close();
        QMessageBox::information(this, "Success", "File encrypted successfully.");
    }
}

void MainWindow::decryptFile() {
    QString fileName = QFileDialog::getOpenFileName(this, "Select File to Decrypt");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly)) return;

    QByteArray data = file.readAll();
    file.close();

    QByteArray decrypted = quantumDecrypt(data);

    QString savePath = fileName + ".dec";
    QFile outFile(savePath);
    if (outFile.open(QIODevice::WriteOnly)) {
        outFile.write(decrypted);
        outFile.close();
        QMessageBox::information(this, "Success", "File decrypted successfully.");
    }
}

QByteArray MainWindow::quantumEncrypt(const QByteArray &data) {
    QByteArray encrypted = data.toBase64();
    std::reverse(encrypted.begin(), encrypted.end());
    return encrypted;
}

QByteArray MainWindow::quantumDecrypt(const QByteArray &data) {
    QByteArray reversed = data;
    std::reverse(reversed.begin(), reversed.end());
    return QByteArray::fromBase64(reversed);
}
