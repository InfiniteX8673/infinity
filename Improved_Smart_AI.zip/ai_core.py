import json
import datetime
import sympy as sp
import pyttsx3
import os

class SmartAI:
    def __init__(self, knowledge_file="knowledge.json", speak=False):
        self.knowledge_file = knowledge_file
        self.speak_enabled = speak
        self.engine = pyttsx3.init() if speak else None
        self.load_knowledge()

    def load_knowledge(self):
        if not os.path.exists(self.knowledge_file):
            with open(self.knowledge_file, "w") as f:
                json.dump({}, f)
        with open(self.knowledge_file, "r") as f:
            self.knowledge = json.load(f)

    def save_knowledge(self):
        with open(self.knowledge_file, "w") as f:
            json.dump(self.knowledge, f, indent=4)

    def speak(self, text):
        if self.speak_enabled and self.engine:
            self.engine.say(text)
            self.engine.runAndWait()

    def solve_math(self, expression):
        try:
            expr = sp.sympify(expression)
            return str(sp.simplify(expr))
        except Exception as e:
            return f"Error solving math: {e}"

    def generate_code(self, query):
        if "python" in query.lower():
            return "# Example Python function\ndef hello():\n    print('Hello, world!')"
        return "Basic code generation only supports simple Python examples."

    def ask(self, query):
        query = query.lower()
        if query in self.knowledge:
            answer = self.knowledge[query]
        elif "solve" in query:
            math_expr = query.split("solve", 1)[-1]
            answer = self.solve_math(math_expr)
        elif "code" in query or "function" in query:
            answer = self.generate_code(query)
        elif "time" in query:
            answer = datetime.datetime.now().strftime("Current time is %H:%M:%S")
        else:
            answer = "I don't know that yet. You can teach me."

        self.speak(answer)
        return answer

    def teach(self, question, answer):
        self.knowledge[question.lower()] = answer
        self.save_knowledge()
        return "Thanks! I've learned something new."